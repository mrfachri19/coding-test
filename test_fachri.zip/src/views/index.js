import Product from "./Product";
import ProductDetail from './ProductId'

export {
    Product,
    ProductDetail,
}