export const URLAPI = 'https://dummyjson.com';
