// ** Reducers Imports
import Product from "../views/store";

const rootReducer = {
  Product,
};

export default rootReducer;
