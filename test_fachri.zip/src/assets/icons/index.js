import IconLogo from "./logo.svg";

export { IconLogo };
